using Microsoft.AspNetCore.Mvc;
using retrievingDataFromJson.Models;
using System.Diagnostics;
using retrievingDataFromJson.Models;
using System.Net;
using Newtonsoft.Json;

namespace retrievingDataFromJson.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        //public IActionResult Privacy()
        //{
        //    return View();
        //}

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult RetrievingData()
        {
            List<ActionsData> retrievingData = new List<ActionsData>();
            retrievingData = GetActionsData();
            return View(retrievingData);
        }

        //string json = System.IO.File.ReadAllText(@"F:\C# projects\Json\retrievingDataFromJson\wwwroot\lib\Data\playbyplay_0022000180.json");

        //YouTuber deserialized = JsonConvert.DeserializeObject<YouTuber>(json);


        private List<ActionsData> GetActionsData()
        {
            List<ActionsData> retrievingData = new List<ActionsData>();
            string url = "https://cdn.nba.com/static/json/liveData/playbyplay/playbyplay_0022000180.json";

            if (url.Trim().Substring(0, 5).ToLower() == "https")
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            string html = string.Empty;

            try
            {
                HttpClient request = new HttpClient();
                request.BaseAddress = new Uri(url);
                HttpResponseMessage response = request.GetAsync("").Result;
                if (response.IsSuccessStatusCode)
                {
                    string result = response.Content.ReadAsStringAsync().Result;
                    html = result;
                    var actions = JsonConvert.DeserializeObject<List<ActionsData>>(html);

                    if (actions != null)
                        retrievingData = actions;
                }
            }
            catch (Exception ex)
            {
                html = "Error occured at the API Endpoint, Error Info. " + ex.Message;
            }
            finally { }

            return retrievingData;

        }

    }
}
