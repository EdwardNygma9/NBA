﻿using System.Net;
using retrievingDataFromJson.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Web;
using Newtonsoft.Json.Linq;

using retrievingDataFromJson.Repository;

namespace retrievingDataFromJson.Controllers
{
    public class retrievingJsonController : Controller
    {

        private readonly IActionsRepository actionsRepository;

        public retrievingJsonController(IActionsRepository actionsRepository)
        {
            this.actionsRepository = actionsRepository; 
        }

        public IActionResult GroupPlayerNamesByTeam()
        {
            var result = actionsRepository.GroupPlayerNamesByTeam();
            return View(result);
        }

        public IActionResult GetAllActionTypeByPlayerName()
        {
            var result = actionsRepository.GetAllActionTypeByPlayerName(ViewBag.playerName);
            return View(result);
        }
    }
}
