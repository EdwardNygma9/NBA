﻿namespace retrievingDataFromJson.Models
{
    public class Actions
    {
        public List<ActionsData> actions { get; set; }
        
    }
}
