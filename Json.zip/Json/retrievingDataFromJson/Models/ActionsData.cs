﻿namespace retrievingDataFromJson.Models
{
    public class ActionsData
    {
            public int actionNumber { get; set; }
            public string clock { get; set; }
            public DateTime timeActual { get; set; }
            public int period { get; set; }
            public string periodType { get; set; }
            public string actionType { get; set; }
            public string subType { get; set; }
            public string[] qualifiers { get; set; }
            public int personId { get; set; }
            public float? x { get; set; }
            public float? y { get; set; }
            public int possession { get; set; }
            public string scoreHome { get; set; }
            public string scoreAway { get; set; }
            public DateTime edited { get; set; }
            public int orderNumber { get; set; }
            public int? xLegacy { get; set; }
            public int? yLegacy { get; set; }
            public int isFieldGoal { get; set; }
            public string side { get; set; }
            public string description { get; set; }
            public int?[] personIdsFilter { get; set; }
            public int teamId { get; set; }
            public string teamTricode { get; set; }
            public string descriptor { get; set; }
            public string jumpBallRecoveredName { get; set; }
            public int jumpBallRecoverdPersonId { get; set; }
            public string playerName { get; set; }
            public string playerNameI { get; set; }
            public string jumpBallWonPlayerName { get; set; }
            public int jumpBallWonPersonId { get; set; }
            public string jumpBallLostPlayerName { get; set; }
            public int jumpBallLostPersonId { get; set; }
            public float shotDistance { get; set; }
            public string shotResult { get; set; }
            public int pointsTotal { get; set; }
            public string assistPlayerNameInitial { get; set; }
            public int assistPersonId { get; set; }
            public int assistTotal { get; set; }
            public int officialId { get; set; }
            public int shotActionNumber { get; set; }
            public int reboundTotal { get; set; }
            public int reboundDefensiveTotal { get; set; }
            public int reboundOffensiveTotal { get; set; }
            public int foulPersonalTotal { get; set; }
            public int foulTechnicalTotal { get; set; }
            public string foulDrawnPlayerName { get; set; }
            public int foulDrawnPersonId { get; set; }
            public int turnoverTotal { get; set; }
            public string stealPlayerName { get; set; }
            public int stealPersonId { get; set; }
            public string value { get; set; }
            public string blockPlayerName { get; set; }
            public int blockPersonId { get; set; }
        }

}

