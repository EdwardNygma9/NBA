﻿using retrievingDataFromJson.Models;
using Microsoft.AspNetCore.Mvc;

namespace retrievingDataFromJson.Repository
{
    public interface IActionsRepository
    {
        Task<ActionResult<Dictionary<string, List<string>>>>GroupPlayerNamesByTeam();
        //IEnumerable<ActionsData> GroupPlayerNamesByTeam();
        Task<ActionResult<List<string>>> GetAllActionTypeByPlayerName(string playerName);
    }
}
