﻿using Newtonsoft.Json;
using retrievingDataFromJson.Models;
using retrievingDataFromJson.Repository;
using System.Net.Http;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace retrievingDataFromJson.Repository
{
    [ApiController]
    [Route("api/[controller]")]
    public class ImplementationRepository : ControllerBase, IActionsRepository
    {
        private readonly HttpClient _httpClient;
        private List<ActionsData> _actions;
        private ActionsData g;
        private Actions actions = null;
        private int i = 0, k=0 ;

        public ImplementationRepository(IHttpClientFactory httpClientFactory)
        {


            _httpClient = httpClientFactory.CreateClient();
            //_actions = new List<Actions>();

            // var webClient = new WebClient();
            // var json = webClient.DownloadString(@"https://cdn.nba.com/static/json/liveData/playbyplay/playbyplay_0022000180.json");
            //string json = System.IO.File.ReadAllText(@"F:/C# projects/Json/retrievingDataFromJson/wwwroot/lib/Dataplaybyplay_0022000180.json");
            //JArray convertJson = JArray.Parse(json);
            //ViewData["retrieveData"] = convertJson;
            //return View();
            // actions = JsonConvert.DeserializeObject<Actions>(json);

        }



        // Model for deserializing API response
        private async Task<Actions> retrieveJsonData()
        {
            try
            {
                var apiUrl = "https://cdn.nba.com/static/json/liveData/playbyplay/playbyplay_0022000180.json";
                var response = await _httpClient.GetStringAsync(apiUrl);
                return JsonConvert.DeserializeObject<Actions>(response);
            }
            catch
            {
                return null;
            }
        }


        [HttpGet("GetAllActionTypeByPlayerName/{playerName}")]
        public async Task<ActionResult<List<string>>> GetAllActionTypeByPlayerName(string playerName)
        {
            var actionData = await retrieveJsonData();

            if (actionData == null)
            {
                return BadRequest("Unable to fetch game data.");
            }

            var actionsByPlayer = actionData.actions
                .Where(play => play.playerName == playerName)
                .Select(play => play.actionType)
                .ToList();

            return Ok(actionsByPlayer);
        }



        //public string ActionTypeForPlayer(ActionsData playerName)
        //{
        //    return playerName.actionType;
        //    //throw new NotImplementedException();
        //}

        [HttpGet("GroupPlayerNamesByTeam")]
        public async Task<ActionResult<Dictionary<string, List<string>>>> GroupPlayerNamesByTeam()
        {
            var actionData = await retrieveJsonData();

            if (actionData == null)
            {
                return BadRequest("Unable to fetch game data.");
            }

            var playersByTeam = actionData.actions
                .GroupBy(play => play.teamTricode)
                .ToDictionary(
                    teamGroup => teamGroup.Key,
                    teamGroup => teamGroup.Select(play => play.playerName).Distinct().ToList()
                );

            return Ok(playersByTeam);
        }



        //public IEnumerable<ActionsData> GroupPlayerNamesByTeam()
        //{
            
          

        //   return _actions.GroupBy(e => e.teamTricode)
        //                  .Select(g => new ActionsData()
        //                  {
        //                      playerName = g.Key
        //                  }).ToList();
            
        //    //throw new NotImplementedException();
        //}
    }
}
